# Welcome to Wavemaker V2

This is the Open Source version I'm releasing into the wild. It's built using HTML/CSS/jQuery
It was not planned but sorta-kinda-happened as the code will show. Which is why version 3 up is a total rebuild!
It will run on pretty much any device as well as on the web, and you can locally install on any desktop.

The LATEST version of this software (not this version) is available at https://wavemaker.cards 

If you want to support me become a patron https://www.patreon.com/wavemakercards


# Run this Locally

**Totally possible - it will run as an offline app on any computer that uses  Google Chrome**
Download the Zip file and unpack it on your computer where ever you want

*You will need Google Chrome for these instructions, but opera, chromium and other blink based browsers should be similar.*

- Download the ZIP file and unzip the contents somewhere on your computer

- Make sure you have google chrome installed

- open google chrome and go to : chrome://extensions

- Enable Developer mode by going to the top right hand corner ond turning on  the "Developer Mode" toggle switch

- A toolbar  should appear with "Load Unpacked Extension" button

- Press this and point the filesystem it at the folder with Wavemaker in

- Then visit chrome://apps and you should see the icon there.


Enjoy.

You will get a pop up warning telling you chrome is in dev mode every now and again is the only Con

## For developers

First of all - Sorry, you guys know how it is when something that's a playabout experiment gets too detailed. Code could use a cleanup, and comments. 

That said - it works, it's a not ideal proof of concept that got the idea off the ground.

You will only need HTML/CSS/JS/jQuery knowledge

The .wmProj file is just JSON renamed so it could be found easily in a Google Drive search (not needed for the extension version)

Feel free to get in there and fix tidy or even add features :)



